package exercicio4;

import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        // Abrindo - receberá os dados do usuário
        Scanner sc = new Scanner(System.in);

        // Gerando número aleatório entre 0 e 10
        Random gerador = new Random();

        // Variaveis
        int numeroDigitado;
        int numeroGerado;

        while (true) {
            System.out.println("\nDigite um número entre 0 e 10: ");
            numeroDigitado = sc.nextInt();
            numeroGerado = gerador.nextInt(10);

            System.out.println("O valor gerado foi " + numeroGerado);

            if (numeroDigitado == numeroGerado) {
                System.out.println("Parabéns, você acertou!");
                break; //sai do while
            }

            System.out.println("Você errou! Tente novamente.");
        }

        // Fechando
        sc.close();
    }
}
