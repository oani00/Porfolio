package exercicio1;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {

        // Instanciando objeto Caixa
        Caixa caixa = new Caixa();

        // Instanciando objetos Produto e imprimindo nome e valor total
        // produto 1
        Produto produto1 = new Produto("Banana", 0.99, 2);
        int quantidade1 = 3;
        System.out.println("\n\nNome do produto: " + produto1.getNome() +
                            "\nValor Total: " + caixa.calculaValorFinal(produto1, quantidade1));

        // produto 2
        Produto produto2 = new Produto("Energético", 5.49, 3);
        int quantidade2 = 7;
        System.out.println("\n\nNome do produto: " + produto2.getNome() +
                "\nValor Total: " + caixa.calculaValorFinal(produto2, quantidade2));

        // produto 3
        Produto produto3 = new Produto("Arroz", 20.00, 1);
        int quantidade3 = 1;
        System.out.println("\n\nNome do produto: " + produto3.getNome() +
                "\nValor Total: " + caixa.calculaValorFinal(produto3, quantidade3));

        // produto 4
        Produto produto4 = new Produto("Chocolate", 4.50, 1);
        int quantidade4 = 12;
        System.out.println("\n\nNome do produto: " + produto4.getNome() +
                "\nValor Total: " + caixa.calculaValorFinal(produto4, quantidade4));

        // produto 5
        Produto produto5 = new Produto("Leite", 3.73, 3);
        int quantidade5 = 5;
        System.out.println("\n\nNome do produto: " + produto5.getNome() +
                "\nValor Total: " + caixa.calculaValorFinal(produto5, quantidade5));

        // produto 6
        Produto produto6 = new Produto("Abacaxi", 2.40, 2);
        int quantidade6 = 1;
        System.out.println("\n\nNome do produto: " + produto6.getNome() +
                "\nValor Total: " + caixa.calculaValorFinal(produto6, quantidade6));

    }


}
