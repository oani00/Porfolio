package exercicio1;

public class Caixa {

    // Construtor
    public Caixa() { }

    public double calculaValorFinal(Produto produto, int quantidade) {

        double valorFinal = produto.getValor() * quantidade;
        double valorFinalComDesconto = 0;

        if (produto.getTipo() == 1) {
            valorFinalComDesconto = valorFinal * 0.9;
        }
        else if (produto.getTipo() == 2) {
            valorFinalComDesconto = valorFinal * 0.8;
        }
        else {
            if (quantidade > 5) {
                valorFinalComDesconto = valorFinal * 0.9;
            }
            else {
                valorFinalComDesconto = valorFinal;
            }
        }

        return valorFinalComDesconto;
    }
}
