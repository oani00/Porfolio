package exercicio1;

import java.util.ArrayList;
import java.util.List;

public class Main2 {
    public static void main(String[] args) {

        // Instanciando objeto Caixa
        Caixa caixa = new Caixa();

        // Inicializando listas de produtos e quantidades
        List<Produto> produtos = new ArrayList<>();
        List<Integer> quantidades = new ArrayList<>();

        // Instanciando objetos Produto e alimentando a lista de produtos e quantidades conforme a tabela
        // produto 1
        produtos.add(new Produto("Banana", 0.99, 2));
        quantidades.add(3);

        // produto 2
        produtos.add(new Produto("Energético", 5.49, 3));
        quantidades.add(7);

        // produto 3
        produtos.add(new Produto("Arroz", 20.00, 1));
        quantidades.add(1);

        // produto 4
        produtos.add(new Produto("Chocolate", 4.50, 1));
        quantidades.add(12);

        // produto 5
        produtos.add(new Produto("Leite", 3.73, 3));
        quantidades.add(5);

        // produto 6
        produtos.add(new Produto("Abacaxi", 2.40, 2));
        quantidades.add(1);

        // Imprimindo nome do produto e valor final de cada item da lista de produtos
        for (int i = 0; i < produtos.size(); i++) {
            System.out.println("\n\nNome do produto: " + produtos.get(i).getNome() +
                    "\nValor Total: " + caixa.calculaValorFinal(produtos.get(i), quantidades.get(i)));
        }

    }

}

