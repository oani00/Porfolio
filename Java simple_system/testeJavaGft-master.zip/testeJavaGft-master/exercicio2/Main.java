package exercicio2;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Stream;

public class Main {

    public static void main(String[] args) {

        // Abrindo - receberá os dados do usuário
        Scanner sc = new Scanner(System.in);

        // Lista dos numeros inseridos pelo usuário
        List<Integer> numeros = new ArrayList<>();

        // Inicializando variável
        int i;

        // Recebendo os 10 números que não devem ser idênticos
        for (i = 0; i < 10; i++) {

            while (true) {
                System.out.println("\nDigite o número " + (i+1) + ":");
                int numeroNovo = sc.nextInt();
                boolean repetido = false;

                // Se a lista estiver vazia adiciona o primeiro numero inserido e sai do while
                if (numeros.size() == 0) {
                    numeros.add(numeroNovo);
                    break; //sai do while
                }

                // Testa se o valor inserido é igual a algum presente na lista antes de adicionar o numero
                for (int j = 0; j < numeros.size(); j++) {
                    if (numeros.get(j) == numeroNovo) {
                        System.out.println("\nDigite um valor único!");
                        repetido = true;
                        break; //sai do for
                    }
                }

                if (!repetido) {
                    numeros.add(numeroNovo);
                    break; //sai do while
                }
            }

        }

        // fechando
        sc.close();

        // Imprimindo o maior número
        int numeroMaior = numeros.get(0);

        for (i = 1; i < numeros.size(); i++) {

            if (numeros.get(i) > numeroMaior) {
                numeroMaior = numeros.get(i);
            }
        }

        System.out.println("\n\nMaior numero: " + numeroMaior);

        // Imprimindo menor número
        int numeroMenor = numeros.get(0);

        for (i = 1; i < numeros.size(); i++) {

            if (numeros.get(i) < numeroMenor) {
                numeroMenor = numeros.get(i);
            }
        }

        System.out.println("\nMenor numero: " + numeroMenor);

        // Imprimindo media aritmetica
        double soma = 0;
        double media = 0;

        for (i = 0; i < numeros.size(); i++) {
            soma += numeros.get(i);
        }

        media = soma / 10;

        System.out.println("\nMédia aritmética: " + media);

        //Imprimindo números acima de 10
        int contadorNumerosAcimaDez = 0;
        List<Integer> numerosAcimaDez = new ArrayList<>();

        for (i = 0; i < numeros.size(); i++) {

            if (numeros.get(i) > 10) {
                contadorNumerosAcimaDez += 1;
                numerosAcimaDez.add(numeros.get(i));
            }

        }

        System.out.println("\n\nExistem " + contadorNumerosAcimaDez + " números acima de dez.");

        if (contadorNumerosAcimaDez > 0) {
            System.out.println("\nOs números são: ");

            for (i = 0; i < numerosAcimaDez.size(); i++) {
                System.out.println("\n" + numerosAcimaDez.get(i));
            }
        }

        // Imprimindo números acima de 50
        int contadorNumerosAcimaCinquenta = 0;
        List<Integer> numerosAcimaCinquenta = new ArrayList<>();

        for (i = 0; i < numeros.size(); i++) {

            if (numeros.get(i) > 50) {
                contadorNumerosAcimaCinquenta += 1;
                numerosAcimaCinquenta.add(numeros.get(i));
            }

        }

        System.out.println("\n\nExistem " + contadorNumerosAcimaCinquenta + " números acima de cinquenta.");

        if (contadorNumerosAcimaCinquenta > 0) {
            System.out.println("\nOs números são: ");

            for (i = 0; i < numerosAcimaCinquenta.size(); i++) {
                System.out.println("\n" + numerosAcimaCinquenta.get(i));
            }
        }

    }

}
