package exercicio3;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        // Abrindo - receberá os dados do usuário
        Scanner sc = new Scanner(System.in);

        // Instanciando objetos
        Icms icms = new Icms();
        Ipi ipi = new Ipi();
        Cofins cofins = new Cofins();

        // Recebendo valor do usuário
        System.out.println("Digite um valor: ");
        double valor = sc.nextDouble();

        // Calculando impostos
        double valorIcms = icms.calculaImposto(valor);
        double valorIpi = ipi.calculaImposto(valor);
        double valorCofins = cofins.calculaImposto(valor);
        double valorTotal = valor + valorIcms + valorIpi + valorCofins;

        // Imprimindo resultado
        System.out.println("ICMS: " + valorIcms);
        System.out.println("IPI: " + valorIpi);
        System.out.println("COFINS: " + valorCofins);
        System.out.println("Valor Final: " + valorTotal);

        // Fechando
        sc.close();
    }
}
