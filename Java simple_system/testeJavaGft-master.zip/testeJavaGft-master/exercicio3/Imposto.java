package exercicio3;

public interface Imposto {

    double calculaImposto(double valor);
}
