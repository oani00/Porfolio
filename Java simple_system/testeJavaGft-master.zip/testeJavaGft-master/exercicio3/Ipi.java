package exercicio3;

public class Ipi implements Imposto {

    public Ipi(){ }

    @Override
    public double calculaImposto(double valor) {

        double imposto = 0;

        if (valor < 25000) {
            imposto = valor * 0.05;
        }
        else {
           imposto = valor * 0.10;
        }

        return imposto;
    }
}
