package exercicio3;

public class Icms implements Imposto {

    public Icms(){ }

    @Override
    public double calculaImposto(double valor) {
        return valor * 0.3;
    }
}
