package exercicio3;

public class Cofins implements Imposto {

    public Cofins(){ }

    @Override
    public double calculaImposto(double valor) {

        double imposto = 0;

        if (valor > 17000) {
            imposto = valor * 0.08;
        }

        return imposto;
    }
}
