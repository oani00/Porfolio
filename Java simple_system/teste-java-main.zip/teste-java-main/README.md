# GFT START_UNI 2021

Repositório com as soluções do desafio de código propostos
