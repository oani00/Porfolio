
const fs = require('fs'); // importa o modulo filesystem

/**
 * ## Recuperação dos dados originais do banco de dados e correcao
 * ### Função 1
 * Recupera o JSON corrompido da API
 * @returns Array de Objetos do Response
 */
function getResponseFromFetch() {
    const response = require('./broken-database.json');
    return response || []; //Tratamento de erro. A função nunca fica sem retorno
}

/**
 * ## Recuperação dos dados originais do banco de dados e correcao
 * ### Função 2
 * Aplica uma correção nomes incorretos do JSON via dicionário fixo.
 * 
 * EX: Dicionário de Traduções: "a" por "æ", "c" por "¢", "o" por "ø", "b" por "ß".
 * @example
 * ```js
 * const str = 'ææææææßßßßßßßß'
 * const translate = {
        'æ': 'a',
        'ß': 'b',
        '¢': 'c',
        'ø': 'o'
    }

    const replaceCharacters = correctNamesFromResponse(str);
    console.log(replaceCharacters); // Deve retornar: 'aaaaaabbbbbbbb'
 * ```
 * @param {any} response Dados incorretos da API
 * @returns Retorna um objeto com os Names Corrigidos
 */
function correctNamesFromResponse(response) {
    const translate = {
        'æ': 'a',
        'ß': 'b',
        '¢': 'c',
        'ø': 'o'
    }

    // Para cada item (produto) do Array
    response.forEach((produto) => { // Para cada propriedade do objeto translate
        Object.entries(translate).forEach(([key, value]) => {  // Enquanto existir caracter incorreto, substituir a string como valor correto
            while (produto.name.includes(key)) {
                produto.name = produto.name.replace(key, value);
            }
        });
    });

    return response;
}

/**
 * ## Recuperação dos dados originais do banco de dados e correcao
 * ### Função 3
 * Faz um casting na propriedade **price** de cada produto do array de objetos **response**
 * @example
 * ```js
 * const obj = [
 *  {
 *      id: 9746439,
        name: 'Home Theater LG com blu-ray 3D, 5.1 canais e 1000W',
        quantity: 80,
        price: '2199',
        category: 'Eletrônicos'
 *  }
 * ]
    const result = castPriceFromStringToDecimal(obj);
    console.log(result); 
    // deve retornar {
 *  //    id: 9746439,
    //    name: 'Home Theater LG com blu-ray 3D, 5.1 canais e 1000W',
    //    quantity: 80,
    //    price: 2199,
    //    category: 'Eletrônicos'
    //}
 *
 * ```
 * @param {any} response Dados incorretos da API
 * @returns Retorna um Objeto com os preços ajustados para tipo numérico (Number)
 */
function castPriceFromStringToDecimal(response) {
    response.forEach((produto) => {
        produto.price = Number(produto.price);
    });
    return response;
}

/**
 * ## Recuperação dos dados originais do banco de dados e correcao
 * ### Função 4
 * Ajusta a propriedade **quantity** dos objetos provindos da **response**
 * @example
 * ```js
 * const obj = [
 *      {
            id: 1911864,
            name: 'Mouse Gamer Predator cestus 510 Fox Preto',
            price: 699,
            category: 'Acessórios'
        }
    ]; 

    const result = fixQuantityFromResponseItens(obj);
    console.log(result);
    // Deve Retornar:
    // {
    //     id: 1911864,
    //     name: 'Mouse Gamer Predator cestus 510 Fox Preto',
    //     price: 699,
    //     category: 'Acessórios',
    //     quantity: 0
    // }
 * ```
 * @param {any} response Dados incorretos da API
 * @returns Retorna um Objeto com as quantidades reatribuidas aos produtos
 */
function fixQuantityFromResponseItens(response) {
    response.forEach((produto) => {
        produto.quantity = produto.quantity || 0;
    });
    return response;
}

/**
 * ## Recuperação dos dados originais do banco de dados e correcao
 * ### Função 5
 * Gera um novo arquivo **JSON** com o objeto completamente restaurado.
 * @file _**fix-broken-database.json**_ - Gerado no diretorio raiz
 * @param {any} fixedResponseObject Objeto do response restaturado
 * @see https://www.codegrepper.com/code-examples/javascript/save+data+from+javascript+to+json+file
 */
function generateJsonFile(fixedResponseObject) {
    fs.writeFile('./saida.json', JSON.stringify(fixedResponseObject, null, 2), (erro) => {
        if (erro) {
            throw new Error(erro);
        }
        console.log('\tArquivo Gerado com sucesso!');
    });
}

/**
 * ## Validação do banco de dados corrigido
 * ### Função 1
 * Ordena o response restaurado por ordem alfabética da **categoria** e depois por ordem crescente dos **ids**
 * @param {any} fixedResponseObject 
 * @see https://stackoverflow.com/questions/51165/how-to-sort-strings-in-javascript
 */
function sortFixItensFromResponse(fixedResponseObject) {
    fixedResponseObject.sort((a, b) => {
        const categorySort = a.category.localeCompare(b.category);
        if (categorySort === 0) {
            return a.id - b.id;
        }
        return categorySort;
    })
    console.log('\tLista de produtos Restaurada!\n');
    fixedResponseObject.map((produto) => console.log('\tProduto ===> ' + produto.name + '\n'));
}

/**
 * ## Validação do banco de dados corrigido
 * ### Função 2
 * Calcula o Total (R$) em Estoque por categoria de produto
 * @param {any} fixedResponseObject 
 * @see https://pt.stackoverflow.com/questions/181922/formatar-moeda-brasileira-em-javascript
 */
function calculateTotalByItemCategory(fixedResponseObject) {
    console.log('\n\tValor em Estoque!')
    const categories = fixedResponseObject.map((produto) => produto.category);

    for (const categoria of [...new Set(categories)]) {
        let totalPorCategoria = 0;
        for (const produto of fixedResponseObject) {
            if (produto.category === categoria) {
                totalPorCategoria += (produto.quantity * produto.price);
            }
        }
        console.log('\tCategoria: ' + categoria + ', Total Em Estoque: ' + totalPorCategoria.toLocaleString('pt-br', { style: 'currency', currency: 'BRL' }));
    }
}

// 1 - Recuperação dos dados originais do banco de dados e correcao
const response = getResponseFromFetch();
const verifyAndReplaceNameFromResponse = correctNamesFromResponse(response);
const verifyAndReplacePriceFromResponse = castPriceFromStringToDecimal(verifyAndReplaceNameFromResponse);
const verifyAndReplaceQuantityFromResponse = fixQuantityFromResponseItens(verifyAndReplacePriceFromResponse);

// Grava um arquivo JSON com o response corrigido
generateJsonFile(verifyAndReplaceQuantityFromResponse);

// 2 - Validação do banco de dados corrigido
sortFixItensFromResponse(verifyAndReplaceQuantityFromResponse);
calculateTotalByItemCategory(verifyAndReplaceQuantityFromResponse);



