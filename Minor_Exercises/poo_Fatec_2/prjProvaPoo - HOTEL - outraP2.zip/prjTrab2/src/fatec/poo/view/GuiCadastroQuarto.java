package fatec.poo.view;

import fatec.poo.model.QuartoHotel;
import java.util.ArrayList;
import javax.swing.JOptionPane;


/**
 *
 * @author ***
 */
public class GuiCadastroQuarto extends javax.swing.JFrame {
    public GuiCadastroQuarto(ArrayList<QuartoHotel> h) {
        initComponents();
        hotel = h;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnInserir = new javax.swing.JButton();
        btnSair = new javax.swing.JButton();
        jLabelNoQuarto = new javax.swing.JLabel();
        jLabelValorDiaria = new javax.swing.JLabel();
        txtNoQuarto = new javax.swing.JTextField();
        txtValorDiaria = new javax.swing.JTextField();
        btnConsultar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Cadastro Quarto");

        btnInserir.setText("Inserir");
        btnInserir.setEnabled(false);
        btnInserir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInserirActionPerformed(evt);
            }
        });

        btnSair.setText("Sair");
        btnSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSairActionPerformed(evt);
            }
        });

        jLabelNoQuarto.setText("No. Quarto");

        jLabelValorDiaria.setText("Valor Diária");

        txtValorDiaria.setEnabled(false);

        btnConsultar.setText("Consultar");
        btnConsultar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsultarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(79, 79, 79)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelNoQuarto)
                            .addComponent(jLabelValorDiaria))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtValorDiaria, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtNoQuarto, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(41, 41, 41)
                        .addComponent(btnConsultar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnInserir, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnSair, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(43, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelNoQuarto)
                    .addComponent(txtNoQuarto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtValorDiaria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelValorDiaria))
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnConsultar)
                    .addComponent(btnInserir)
                    .addComponent(btnSair))
                .addContainerGap(34, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSairActionPerformed
        dispose();
    }//GEN-LAST:event_btnSairActionPerformed

    private void btnConsultarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsultarActionPerformed
        if (txtNoQuarto.getText().equals("")) {
            JOptionPane.showMessageDialog(this, "O número do quarto precisa ser digitado!");
            txtNoQuarto.requestFocus();
        }
        else {
            
            int quarto;
            for (quarto = 0; quarto < hotel.size(); quarto++){ 
                if (hotel.get(quarto) instanceof QuartoHotel)
                    if (((QuartoHotel)hotel.get(quarto)).getNumQuarto() == Integer.parseInt(txtNoQuarto.getText())){
                       break;
                   }
            } 

            if (quarto < hotel.size()){
               posQuarto = quarto; //localizou o objeto QuartoHotel no ArrayList
            }else{
               posQuarto = -1; //não localizou o objeto QuartoHotel no ArrayList
            }            

            if (posQuarto >= 0) {
                txtValorDiaria.setText(String.valueOf(hotel.get(posQuarto).getValorDiaria()));

                txtValorDiaria.setEnabled(false);
            }
            else{
                btnConsultar.setEnabled(false);
                btnInserir.setEnabled(true);

                txtValorDiaria.setText(null);

                txtNoQuarto.setEnabled(false);
                txtValorDiaria.setEnabled(true);

                txtValorDiaria.requestFocus();
            }
        }
    }//GEN-LAST:event_btnConsultarActionPerformed

    private void btnInserirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInserirActionPerformed
        if (txtValorDiaria.getText().equals("")) {
            JOptionPane.showMessageDialog(this, "O valor da diária precisa ser digitado!");
            txtValorDiaria.requestFocus();
        }
        else {
            h = new QuartoHotel(Integer.parseInt(txtNoQuarto.getText()),
                                Double.parseDouble(txtValorDiaria.getText()));
            hotel.add(h);

            txtNoQuarto.setText(null);
            txtValorDiaria.setText(null);

            btnConsultar.setEnabled(true);
            btnInserir.setEnabled(false);

            txtNoQuarto.setEnabled(true);
            txtValorDiaria.setEnabled(false);

            txtNoQuarto.requestFocus();
        }
    }//GEN-LAST:event_btnInserirActionPerformed

   
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnConsultar;
    private javax.swing.JButton btnInserir;
    private javax.swing.JButton btnSair;
    private javax.swing.JLabel jLabelNoQuarto;
    private javax.swing.JLabel jLabelValorDiaria;
    private javax.swing.JTextField txtNoQuarto;
    private javax.swing.JTextField txtValorDiaria;
    // End of variables declaration//GEN-END:variables
    
    private ArrayList<QuartoHotel> hotel;
    private QuartoHotel h = null;
    private int posQuarto;
}
