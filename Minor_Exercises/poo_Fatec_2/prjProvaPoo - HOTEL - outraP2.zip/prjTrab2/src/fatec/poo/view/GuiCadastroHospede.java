package fatec.poo.view;

import fatec.poo.model.Hospede;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author ***
 */
public class GuiCadastroHospede extends javax.swing.JFrame {
    public GuiCadastroHospede(ArrayList<Hospede> ho) {
        initComponents();
        hospedes = ho;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup2 = new javax.swing.ButtonGroup();
        txtTaxaDesconto = new javax.swing.JTextField();
        jLabelEndereco = new javax.swing.JLabel();
        jLabelTaxaDesconto = new javax.swing.JLabel();
        txtCpf = new javax.swing.JTextField();
        txtNome = new javax.swing.JTextField();
        txtEndereco = new javax.swing.JTextField();
        txtTelefone = new javax.swing.JTextField();
        jLabelTelefone = new javax.swing.JLabel();
        btnConsultar = new javax.swing.JButton();
        btnInserir = new javax.swing.JButton();
        btnSair = new javax.swing.JButton();
        btnAlterar = new javax.swing.JButton();
        jLabelCpf = new javax.swing.JLabel();
        btnExcluir = new javax.swing.JButton();
        jLabelNome = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        rbtnFeminino = new javax.swing.JRadioButton();
        rbtnMasculino = new javax.swing.JRadioButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Cadastro Hóspede");

        txtTaxaDesconto.setEnabled(false);

        jLabelEndereco.setText("Endereço");

        jLabelTaxaDesconto.setText("Taxa Desconto (%)");

        txtNome.setEnabled(false);

        txtEndereco.setEnabled(false);

        txtTelefone.setEnabled(false);

        jLabelTelefone.setText("Telefone");

        btnConsultar.setText("Consultar");
        btnConsultar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsultarActionPerformed(evt);
            }
        });

        btnInserir.setText("Inserir");
        btnInserir.setEnabled(false);
        btnInserir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInserirActionPerformed(evt);
            }
        });

        btnSair.setText("Sair");
        btnSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSairActionPerformed(evt);
            }
        });

        btnAlterar.setText("Alterar");
        btnAlterar.setEnabled(false);
        btnAlterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAlterarActionPerformed(evt);
            }
        });

        jLabelCpf.setText("CPF");

        btnExcluir.setText("Excluir");
        btnExcluir.setEnabled(false);
        btnExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcluirActionPerformed(evt);
            }
        });

        jLabelNome.setText("Nome");

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Sexo"));

        buttonGroup2.add(rbtnFeminino);
        rbtnFeminino.setText("Feminino");
        rbtnFeminino.setEnabled(false);

        buttonGroup2.add(rbtnMasculino);
        rbtnMasculino.setText("Masculino");
        rbtnMasculino.setEnabled(false);
        rbtnMasculino.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnMasculinoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(rbtnMasculino)
                    .addComponent(rbtnFeminino))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(rbtnFeminino)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(rbtnMasculino)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabelTaxaDesconto)
                        .addGap(18, 18, 18)
                        .addComponent(txtTaxaDesconto))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelCpf)
                            .addComponent(jLabelEndereco)
                            .addComponent(jLabelTelefone))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtEndereco)
                            .addComponent(txtTelefone)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabelNome)
                        .addGap(39, 39, 39)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtNome, javax.swing.GroupLayout.DEFAULT_SIZE, 186, Short.MAX_VALUE)
                            .addComponent(txtCpf))
                        .addGap(18, 18, 18)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnConsultar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnInserir)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnAlterar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnExcluir)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnSair)))
                .addContainerGap(28, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabelCpf)
                            .addComponent(txtCpf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabelNome)
                            .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelEndereco)
                    .addComponent(txtEndereco, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelTelefone)
                    .addComponent(txtTelefone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelTaxaDesconto)
                    .addComponent(txtTaxaDesconto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnConsultar)
                    .addComponent(btnInserir)
                    .addComponent(btnAlterar)
                    .addComponent(btnExcluir)
                    .addComponent(btnSair))
                .addContainerGap(42, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSairActionPerformed
        dispose();
    }//GEN-LAST:event_btnSairActionPerformed

    private void btnConsultarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsultarActionPerformed
        if (txtCpf.getText().equals("")) {
            JOptionPane.showMessageDialog(this, "O CPF precisa ser digitado!");
            txtCpf.requestFocus();
        }
        else {
            int hosp;
            for (hosp = 0; hosp < hospedes.size(); hosp++) {
                if (hospedes.get(hosp) instanceof Hospede)
                    if (((Hospede)hospedes.get(hosp)).getCpf().equals(txtCpf.getText())){
                       break;
                   }
            }

            if (hosp < hospedes.size()){
                posHospede = hosp;
            } 
            else {
                posHospede = -1;
            }            

            if (posHospede >= 0) {
                txtNome.setText((hospedes.get(posHospede)).getNome());
                txtEndereco.setText((hospedes.get(posHospede)).getEndereco());
                txtTelefone.setText((hospedes.get(posHospede)).getTelefone());
                txtTaxaDesconto.setText(String.valueOf(hospedes.get(posHospede).getTxDesconto()));

                switch (hospedes.get(hosp).getSexo()) {
                    case "F": rbtnFeminino.setSelected(true);
                        break;
                    case "M": rbtnMasculino.setSelected(true);
                        break;
                }
                
                txtCpf.setEnabled(false);
                txtNome.setEnabled(false);
                txtEndereco.setEnabled(true);
                txtTelefone.setEnabled(true);
                txtTaxaDesconto.setEnabled(true);

                btnConsultar.setEnabled(false);
                btnAlterar.setEnabled(true);
                btnExcluir.setEnabled(true);
                
                rbtnFeminino.setEnabled(true);
                rbtnMasculino.setEnabled(true);
            }
            else{
                txtCpf.setEnabled(false);
                txtNome.setEnabled(true);
                txtEndereco.setEnabled(true);
                txtTelefone.setEnabled(true);
                txtTaxaDesconto.setEnabled(true);

                txtNome.requestFocus();

                btnConsultar.setEnabled(false);
                btnInserir.setEnabled(true);
                
                rbtnFeminino.setEnabled(true);
                rbtnMasculino.setEnabled(true);
            }
        }
    }//GEN-LAST:event_btnConsultarActionPerformed

    private void btnInserirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInserirActionPerformed
        if (txtNome.getText().equals("") || txtEndereco.getText().equals("") ||
                                            txtTelefone.getText().equals("") ||
                                            txtTaxaDesconto.getText().equals("")) {
        
            JOptionPane.showMessageDialog(this, "Todos os campos devem ser digitados!");
            txtNome.requestFocus();
        }
        else {
            ho = new Hospede(txtCpf.getText(), txtNome.getText());

            ((Hospede)ho).setEndereco(txtEndereco.getText());
            ((Hospede)ho).setTelefone(txtTelefone.getText());
            ((Hospede)ho).setTxDesconto(Double.parseDouble(txtTaxaDesconto.getText()));

            if(rbtnFeminino.isSelected()){
                ((Hospede)ho).setSexo("F");
            }
            else if (rbtnMasculino.isSelected()){
                ((Hospede)ho).setSexo("M");
            }
            
            hospedes.add(ho);

            txtCpf.setText(null);
            txtNome.setText(null);
            txtEndereco.setText(null);
            txtTelefone.setText(null);
            txtTaxaDesconto.setText(null);

            btnConsultar.setEnabled(true);
            btnInserir.setEnabled(false);

            txtCpf.setEnabled(true);
            txtNome.setEnabled(false);
            txtEndereco.setEnabled(false);
            txtTelefone.setEnabled(false);
            txtTaxaDesconto.setEnabled(false);

            txtCpf.requestFocus();
            
            buttonGroup2.clearSelection();
            
            rbtnFeminino.setEnabled(false);
            rbtnMasculino.setEnabled(false);
        }
    }//GEN-LAST:event_btnInserirActionPerformed

    private void btnAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAlterarActionPerformed
        hospedes.get(posHospede).setEndereco(txtEndereco.getText());
        hospedes.get(posHospede).setTelefone(txtTelefone.getText());
        hospedes.get(posHospede).setTxDesconto(Double.parseDouble(txtTaxaDesconto.getText()));
        
        if(rbtnFeminino.isSelected()){
            hospedes.get(posHospede).setSexo("F");
        }
        else if (rbtnMasculino.isSelected()){
            hospedes.get(posHospede).setSexo("M");
        }
        
        txtCpf.setText(null);
        txtNome.setText(null);
        txtEndereco.setText(null);
        txtTelefone.setText(null);
        txtTaxaDesconto.setText(null);
        
        txtCpf.setEnabled(true);
        txtNome.setEnabled(false);
        txtEndereco.setEnabled(false);
        txtTelefone.setEnabled(false);
        txtTaxaDesconto.setEnabled(false);

        btnConsultar.setEnabled(true);
        btnAlterar.setEnabled(false);
        btnExcluir.setEnabled(false);
        
        rbtnFeminino.setEnabled(false);
        rbtnMasculino.setEnabled(false);
        
        buttonGroup2.clearSelection();
        
        txtCpf.requestFocus();
    }//GEN-LAST:event_btnAlterarActionPerformed

    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcluirActionPerformed
        if (posHospede >= 0) {
            hospedes.remove(posHospede);
            posHospede -= 1;
        }
        
        txtCpf.setText(null);
        txtNome.setText(null);
        txtEndereco.setText(null);
        txtTelefone.setText(null);
        txtTaxaDesconto.setText(null);
        
        txtCpf.setEnabled(true);
        txtNome.setEnabled(false);
        txtEndereco.setEnabled(false);
        txtTelefone.setEnabled(false);
        txtTaxaDesconto.setEnabled(false);
        
        btnConsultar.setEnabled(true);
        btnAlterar.setEnabled(false);
        btnExcluir.setEnabled(false);
        
        rbtnFeminino.setEnabled(false);
        rbtnMasculino.setEnabled(false);
        
        buttonGroup2.clearSelection();
        
        txtCpf.requestFocus();
    }//GEN-LAST:event_btnExcluirActionPerformed

    private void rbtnMasculinoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnMasculinoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rbtnMasculinoActionPerformed

   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAlterar;
    private javax.swing.JButton btnConsultar;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JButton btnInserir;
    private javax.swing.JButton btnSair;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JLabel jLabelCpf;
    private javax.swing.JLabel jLabelEndereco;
    private javax.swing.JLabel jLabelNome;
    private javax.swing.JLabel jLabelTaxaDesconto;
    private javax.swing.JLabel jLabelTelefone;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JRadioButton rbtnFeminino;
    private javax.swing.JRadioButton rbtnMasculino;
    private javax.swing.JTextField txtCpf;
    private javax.swing.JTextField txtEndereco;
    private javax.swing.JTextField txtNome;
    private javax.swing.JTextField txtTaxaDesconto;
    private javax.swing.JTextField txtTelefone;
    // End of variables declaration//GEN-END:variables

    private ArrayList<Hospede> hospedes;
    private Hospede ho = null;
    private int posHospede;
}
