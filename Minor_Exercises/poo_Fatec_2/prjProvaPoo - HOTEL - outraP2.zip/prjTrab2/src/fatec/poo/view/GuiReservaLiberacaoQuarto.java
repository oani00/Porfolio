package fatec.poo.view;

import fatec.poo.model.Atendente;
import fatec.poo.model.Hospede;
import fatec.poo.model.QuartoHotel;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import javax.swing.JOptionPane;

/**
 *
 * @author ***
 */
public class GuiReservaLiberacaoQuarto extends javax.swing.JFrame {
    public GuiReservaLiberacaoQuarto(ArrayList<QuartoHotel> h, 
                                     ArrayList<Atendente> a, 
                                     ArrayList<Hospede> ho) {
        initComponents();
        
        hotel = h;
        atendentes = a;
        hospedes = ho;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextFieldDataSaida1 = new javax.swing.JTextField();
        jLabelRegFunc = new javax.swing.JLabel();
        jLabelCpfHospede = new javax.swing.JLabel();
        jLabelNoQuarto = new javax.swing.JLabel();
        jLabelDataEntrada = new javax.swing.JLabel();
        jLabelDataSaida = new javax.swing.JLabel();
        jLabelValorPagar = new javax.swing.JLabel();
        jLabelSituacao = new javax.swing.JLabel();
        btnReservar = new javax.swing.JButton();
        btnLiberar = new javax.swing.JButton();
        bntSair = new javax.swing.JButton();
        txtCpfHospede = new javax.swing.JTextField();
        txtRegFunc = new javax.swing.JTextField();
        btnRegFunc = new javax.swing.JButton();
        btnCpfHospede = new javax.swing.JButton();
        lblRegFuncResult = new javax.swing.JLabel();
        lblCpfHospedeResult = new javax.swing.JLabel();
        lblSituacao = new javax.swing.JLabel();
        txtNoQuarto = new javax.swing.JTextField();
        txtDataEntrada = new javax.swing.JTextField();
        txtDataSaida = new javax.swing.JTextField();
        btnNoQuarto = new javax.swing.JButton();
        lblValorPagar = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Reserva/Liberação Quarto");

        jLabelRegFunc.setText("Reg. Func.");

        jLabelCpfHospede.setText("CPF Hospede");

        jLabelNoQuarto.setText("No. Quarto");

        jLabelDataEntrada.setText("Data de Entrada");

        jLabelDataSaida.setText("Data de Saída");

        jLabelValorPagar.setText("Valor a Pagar");

        jLabelSituacao.setText("Situação");

        btnReservar.setText("Reservar");
        btnReservar.setEnabled(false);
        btnReservar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReservarActionPerformed(evt);
            }
        });

        btnLiberar.setText("Liberar");
        btnLiberar.setEnabled(false);
        btnLiberar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLiberarActionPerformed(evt);
            }
        });

        bntSair.setText("Sair");
        bntSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bntSairActionPerformed(evt);
            }
        });

        txtCpfHospede.setEnabled(false);

        btnRegFunc.setText("...");
        btnRegFunc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegFuncActionPerformed(evt);
            }
        });

        btnCpfHospede.setText("...");
        btnCpfHospede.setEnabled(false);
        btnCpfHospede.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCpfHospedeActionPerformed(evt);
            }
        });

        lblRegFuncResult.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        lblCpfHospedeResult.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        lblSituacao.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        txtNoQuarto.setEnabled(false);

        txtDataEntrada.setEnabled(false);

        txtDataSaida.setEnabled(false);

        btnNoQuarto.setText("...");
        btnNoQuarto.setEnabled(false);
        btnNoQuarto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNoQuartoActionPerformed(evt);
            }
        });

        lblValorPagar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabelNoQuarto)
                                .addGap(46, 46, 46)
                                .addComponent(txtNoQuarto, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(btnNoQuarto)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabelSituacao)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(lblSituacao, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabelCpfHospede)
                                    .addComponent(jLabelRegFunc))
                                .addGap(30, 30, 30)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtCpfHospede)
                                    .addComponent(txtRegFunc))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(btnCpfHospede)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(lblCpfHospedeResult, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(btnRegFunc)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(lblRegFuncResult, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addGap(6, 6, 6))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelDataEntrada)
                            .addComponent(jLabelDataSaida)
                            .addComponent(jLabelValorPagar))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtDataSaida, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtDataEntrada, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(lblValorPagar, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(110, 110, 110)
                                .addComponent(btnReservar)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnLiberar)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(bntSair)))))
                .addContainerGap(25, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblRegFuncResult, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabelRegFunc)
                        .addComponent(btnRegFunc)
                        .addComponent(txtRegFunc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabelCpfHospede)
                        .addComponent(btnCpfHospede)
                        .addComponent(txtCpfHospede, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(lblCpfHospedeResult, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabelNoQuarto)
                        .addComponent(btnNoQuarto)
                        .addComponent(txtNoQuarto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(lblSituacao, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createSequentialGroup()
                            .addGap(8, 8, 8)
                            .addComponent(jLabelSituacao))))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelDataEntrada)
                    .addComponent(txtDataEntrada, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelDataSaida)
                    .addComponent(txtDataSaida, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(52, 52, 52)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnReservar)
                            .addComponent(btnLiberar)
                            .addComponent(bntSair)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(lblValorPagar, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(38, 38, 38)
                        .addComponent(jLabelValorPagar)))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bntSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bntSairActionPerformed
        dispose();
    }//GEN-LAST:event_bntSairActionPerformed

    private void btnRegFuncActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegFuncActionPerformed
        //garantir campos limpos caso pós liberação
        txtCpfHospede.setText(null);
        txtNoQuarto.setText(null);
        txtDataEntrada.setText(null);
        txtDataSaida.setText(null);
        
        lblCpfHospedeResult.setText(null);
        lblSituacao.setText(null);
        lblValorPagar.setText(null);
        
        
        
        int atend;
        
        for (atend = 0; atend < atendentes.size(); atend++) {
            if (atendentes.get(atend) instanceof Atendente)
                if (((Atendente)atendentes.get(atend)).getRegFunc().equals(txtRegFunc.getText())){
                   break;
               }
        }
        
        if (atend < atendentes.size()){
            posAtendente = atend;
        } 
        else {
            posAtendente = -1;
        }            
        
        if (posAtendente >= 0) {
            lblRegFuncResult.setText(((atendentes.get(posAtendente)).getNome()));
            
            txtCpfHospede.setEnabled(true);
            txtRegFunc.setEnabled(false);
            txtCpfHospede.requestFocus();
            
            btnRegFunc.setEnabled(false);
            btnCpfHospede.setEnabled(true);
        }
        else {
            JOptionPane.showMessageDialog(this, "Atendente não cadastrado!!!");
            txtRegFunc.setText(null);
            lblRegFuncResult.setText(null);
            txtRegFunc.requestFocus();
        }
    }//GEN-LAST:event_btnRegFuncActionPerformed

    private void btnCpfHospedeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCpfHospedeActionPerformed
        int hosp;
        for (hosp = 0; hosp < hospedes.size(); hosp++) {
            if (hospedes.get(hosp) instanceof Hospede)
                if (((Hospede)hospedes.get(hosp)).getCpf().equals(txtCpfHospede.getText())){
                   break;
               }
        }
        
        if (hosp < hospedes.size()){
            posHospede = hosp;
        } 
        else {
            posHospede = -1;
        }            
        
        if (posHospede >= 0) {
            if (hospedes.get(hosp).getQuartoHotel() != null) {
                txtNoQuarto.setText(String.valueOf(hospedes
                                                        .get(hosp)
                                                        .getQuartoHotel()
                                                        .getNumQuarto()));
                
                txtDataEntrada.setText(hospedes
                                            .get(hosp)
                                            .getQuartoHotel()
                                            .getDataEntrada());
            
                posQuarto = hotel.indexOf(hospedes.get(hosp).getQuartoHotel());
                
                lblCpfHospedeResult.setText(((hospedes.get(posHospede)).getNome()));
                lblSituacao.setText("Ocupado");
                
                txtDataSaida.setEnabled(true);
                txtDataSaida.requestFocus();
                txtCpfHospede.setEnabled(false);
                
                btnLiberar.setEnabled(true);
                btnCpfHospede.setEnabled(false);
            }
            else {
            lblCpfHospedeResult.setText(((hospedes.get(posHospede)).getNome()));
            
            txtNoQuarto.setEnabled(true);
            txtCpfHospede.setEnabled(false);
            txtNoQuarto.requestFocus();
            
            btnCpfHospede.setEnabled(false);
            btnNoQuarto.setEnabled(true);
            
            }
        }
        else {
            JOptionPane.showMessageDialog(this, "Hospede não cadastrado!!!");
            txtCpfHospede.setText(null);
            lblCpfHospedeResult.setText(null);
            txtCpfHospede.requestFocus();
        }
    }//GEN-LAST:event_btnCpfHospedeActionPerformed

    private void btnNoQuartoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNoQuartoActionPerformed
        int quarto;
        for (quarto = 0; quarto < hotel.size(); quarto++){ 
            if (hotel.get(quarto) instanceof QuartoHotel)
                if (((QuartoHotel)hotel.get(quarto)).getNumQuarto() == Integer.parseInt(txtNoQuarto.getText())){
                   break;
               }
        } 
        
        if (quarto < hotel.size()){
           posQuarto = quarto; 
        }else{
           posQuarto = -1; 
        }            
        
        if (posQuarto >= 0) {
            if ((hotel.get(posQuarto)).getSituacao()) {
                lblSituacao.setText("Ocupado");
            }
            else {
                lblSituacao.setText("Livre");
            }
            
            txtDataEntrada.setEnabled(true);
            txtNoQuarto.setEnabled(false);
            txtDataEntrada.requestFocus();
            
            btnNoQuarto.setEnabled(false);
            btnReservar.setEnabled(true);
        }
        else {
            JOptionPane.showMessageDialog(this, "Quarto não cadastrado!!!");
            txtNoQuarto.setText(null);
            lblSituacao.setText(null);
            txtNoQuarto.requestFocus();
        }
    }//GEN-LAST:event_btnNoQuartoActionPerformed

    private void btnReservarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReservarActionPerformed
        if (txtDataEntrada.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "A data de entrada precisa ser preenchida!");
            txtDataEntrada.requestFocus();
        }
        else {
            hotel.get(posQuarto).reservar(hospedes.get(posHospede), 
                                          atendentes.get(posAtendente));
        
            hotel.get(posQuarto).setDataEntrada(txtDataEntrada.getText());
            
            txtDataEntrada.setText(null);
            txtNoQuarto.setText(null);
            txtCpfHospede.setText(null);
            txtRegFunc.setText(null);
            
            lblSituacao.setText(null);
            lblCpfHospedeResult.setText(null);
            lblRegFuncResult.setText(null);
            
            txtDataEntrada.setEnabled(false);
            txtRegFunc.setEnabled(true);
            txtRegFunc.requestFocus();
            
            btnReservar.setEnabled(false);
            btnRegFunc.setEnabled(true);
            
        }
    }//GEN-LAST:event_btnReservarActionPerformed

    private void btnLiberarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLiberarActionPerformed
        if (txtDataSaida.getText().equals("")) {
            JOptionPane.showMessageDialog(this, "A data de saída precisa ser preenchida!");
            txtDataSaida.requestFocus();
        }
        else {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            DecimalFormat df = new DecimalFormat("#,##0.00");

            Calendar data1 = Calendar.getInstance();
            Calendar data2 = Calendar.getInstance();

            int dias;
            try {                
                data1.setTime(sdf.parse(txtDataEntrada.getText()));
                data2.setTime(sdf.parse(txtDataSaida.getText()));
            } 
            catch (java.text.ParseException e ) { }

            dias = data2.get(Calendar.DAY_OF_YEAR) - data1.get(Calendar.DAY_OF_YEAR);

            double valorPagar;
            valorPagar = hotel.get(posQuarto).liberar(dias, (hospedes
                                                                .get(posHospede))
                                                                .getTxDesconto());

            lblValorPagar.setText(df.format(valorPagar));

            txtDataSaida.setEnabled(false);
            txtRegFunc.setEnabled(true);

            txtRegFunc.setText(null);

            lblRegFuncResult.setText(null);
            lblSituacao.setText("Liberado");

            btnLiberar.setEnabled(false);
            btnRegFunc.setEnabled(true);
            
            txtRegFunc.requestFocus();
        }
    }//GEN-LAST:event_btnLiberarActionPerformed

   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bntSair;
    private javax.swing.JButton btnCpfHospede;
    private javax.swing.JButton btnLiberar;
    private javax.swing.JButton btnNoQuarto;
    private javax.swing.JButton btnRegFunc;
    private javax.swing.JButton btnReservar;
    private javax.swing.JLabel jLabelCpfHospede;
    private javax.swing.JLabel jLabelDataEntrada;
    private javax.swing.JLabel jLabelDataSaida;
    private javax.swing.JLabel jLabelNoQuarto;
    private javax.swing.JLabel jLabelRegFunc;
    private javax.swing.JLabel jLabelSituacao;
    private javax.swing.JLabel jLabelValorPagar;
    private javax.swing.JTextField jTextFieldDataSaida1;
    private javax.swing.JLabel lblCpfHospedeResult;
    private javax.swing.JLabel lblRegFuncResult;
    private javax.swing.JLabel lblSituacao;
    private javax.swing.JLabel lblValorPagar;
    private javax.swing.JTextField txtCpfHospede;
    private javax.swing.JTextField txtDataEntrada;
    private javax.swing.JTextField txtDataSaida;
    private javax.swing.JTextField txtNoQuarto;
    private javax.swing.JTextField txtRegFunc;
    // End of variables declaration//GEN-END:variables
    
    private ArrayList<QuartoHotel> hotel;
    private ArrayList<Atendente> atendentes;
    private ArrayList<Hospede> hospedes;
    
    private int posQuarto;
    private int posAtendente;
    private int posHospede;
}
