package fatec.poo.view;

import fatec.poo.model.Atendente;
import fatec.poo.model.Hospede;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author ***
 */
public class GuiCadastroAtendente extends javax.swing.JFrame {
    public GuiCadastroAtendente(ArrayList<Atendente> a) {
        initComponents();
        atendentes = a;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jLabelNome = new javax.swing.JLabel();
        jLabelEndereco = new javax.swing.JLabel();
        jLabelTelefone = new javax.swing.JLabel();
        btnConsultar = new javax.swing.JButton();
        btnInserir = new javax.swing.JButton();
        btnAlterar = new javax.swing.JButton();
        btnExcluir = new javax.swing.JButton();
        btnSair = new javax.swing.JButton();
        jPanelTurno = new javax.swing.JPanel();
        rbtnManha = new javax.swing.JRadioButton();
        rbtnTarde = new javax.swing.JRadioButton();
        rbtnNoite = new javax.swing.JRadioButton();
        jLabelRegFunc = new javax.swing.JLabel();
        txtRegFuncional = new javax.swing.JTextField();
        txtNome = new javax.swing.JTextField();
        txtEndereco = new javax.swing.JTextField();
        txtTelefone = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Cadastro Atendente");

        jLabelNome.setText("Nome");

        jLabelEndereco.setText("Endereço");

        jLabelTelefone.setText("Telefone");

        btnConsultar.setText("Consultar");
        btnConsultar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsultarActionPerformed(evt);
            }
        });

        btnInserir.setText("Inserir");
        btnInserir.setEnabled(false);
        btnInserir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInserirActionPerformed(evt);
            }
        });

        btnAlterar.setText("Alterar");
        btnAlterar.setEnabled(false);
        btnAlterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAlterarActionPerformed(evt);
            }
        });

        btnExcluir.setText("Excluir");
        btnExcluir.setEnabled(false);
        btnExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcluirActionPerformed(evt);
            }
        });

        btnSair.setText("Sair");
        btnSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSairActionPerformed(evt);
            }
        });

        jPanelTurno.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 255, 255), 1, true)), "Turno", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.ABOVE_TOP));
        jPanelTurno.setName(""); // NOI18N

        buttonGroup1.add(rbtnManha);
        rbtnManha.setText("Manhã");
        rbtnManha.setEnabled(false);

        buttonGroup1.add(rbtnTarde);
        rbtnTarde.setText("Tarde");
        rbtnTarde.setEnabled(false);

        buttonGroup1.add(rbtnNoite);
        rbtnNoite.setText("Noite");
        rbtnNoite.setEnabled(false);

        javax.swing.GroupLayout jPanelTurnoLayout = new javax.swing.GroupLayout(jPanelTurno);
        jPanelTurno.setLayout(jPanelTurnoLayout);
        jPanelTurnoLayout.setHorizontalGroup(
            jPanelTurnoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelTurnoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(rbtnManha)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(rbtnTarde)
                .addGap(75, 75, 75)
                .addComponent(rbtnNoite)
                .addContainerGap())
        );
        jPanelTurnoLayout.setVerticalGroup(
            jPanelTurnoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelTurnoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanelTurnoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rbtnManha)
                    .addComponent(rbtnTarde)
                    .addComponent(rbtnNoite))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabelRegFunc.setText("Reg. Funcional");

        txtNome.setEnabled(false);

        txtEndereco.setEnabled(false);

        txtTelefone.setEnabled(false);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnConsultar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnInserir)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnAlterar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnExcluir)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnSair))
                    .addComponent(jPanelTurno, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelRegFunc)
                            .addComponent(jLabelNome)
                            .addComponent(jLabelEndereco)
                            .addComponent(jLabelTelefone))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtRegFuncional)
                            .addComponent(txtNome)
                            .addComponent(txtEndereco)
                            .addComponent(txtTelefone))))
                .addContainerGap(39, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelRegFunc)
                    .addComponent(txtRegFuncional, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelNome)
                    .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelEndereco)
                    .addComponent(txtEndereco, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelTelefone)
                    .addComponent(txtTelefone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jPanelTurno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnConsultar)
                    .addComponent(btnInserir)
                    .addComponent(btnAlterar)
                    .addComponent(btnExcluir)
                    .addComponent(btnSair))
                .addContainerGap(34, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSairActionPerformed
        dispose();
    }//GEN-LAST:event_btnSairActionPerformed

    private void btnConsultarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsultarActionPerformed
        if (txtRegFuncional.getText().equals("")) {
            JOptionPane.showMessageDialog(this, "O número do registro funcional precisa ser digitado!");
            txtRegFuncional.requestFocus();
        }
        else {
            int atend;
            for (atend = 0; atend < atendentes.size(); atend++) {
                if (atendentes.get(atend) instanceof Atendente)
                    if (((Atendente)atendentes.get(atend)).getRegFunc().equals(txtRegFuncional.getText())){
                       break;
                   }
            }

            if (atend < atendentes.size()){
                posAtendente = atend;
            } 
            else {
                posAtendente = -1;
            }            

            if (posAtendente >= 0) {
                txtNome.setText((atendentes.get(posAtendente)).getNome());
                txtEndereco.setText((atendentes.get(posAtendente)).getEndereco());
                txtTelefone.setText((atendentes.get(posAtendente)).getTelefone());

                switch (atendentes.get(atend).getTurno()) {
                    case "M": rbtnManha.setSelected(true);
                        break;
                    case "T": rbtnTarde.setSelected(true);
                        break;
                    case "N": rbtnNoite.setSelected(true);
                        break;
                }

                txtRegFuncional.setEnabled(false);
                txtNome.setEnabled(false);
                txtEndereco.setEnabled(true);
                txtTelefone.setEnabled(true);

                btnConsultar.setEnabled(false);
                btnAlterar.setEnabled(true);
                btnExcluir.setEnabled(true);

                rbtnManha.setEnabled(true);
                rbtnTarde.setEnabled(true);
                rbtnNoite.setEnabled(true);
            }
            else{
                txtRegFuncional.setEnabled(false);
                txtNome.setEnabled(true);
                txtEndereco.setEnabled(true);
                txtTelefone.setEnabled(true);

                txtNome.requestFocus();

                rbtnManha.setEnabled(true);
                rbtnNoite.setEnabled(true);
                rbtnTarde.setEnabled(true);

                btnConsultar.setEnabled(false);
                btnInserir.setEnabled(true);
            }
        }
    }//GEN-LAST:event_btnConsultarActionPerformed

    private void btnInserirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInserirActionPerformed
        if (txtNome.getText().equals("") || txtEndereco.getText().equals("") ||
                                            txtTelefone.getText().equals("") ||
                                            !(rbtnManha.isSelected() || 
                                              rbtnTarde.isSelected() ||
                                              rbtnNoite.isSelected())) {
        
            JOptionPane.showMessageDialog(this, "Todos os campos devem ser digitados/selecionados!");
            txtNome.requestFocus();
        }
        else {
            a = new Atendente(txtRegFuncional.getText(), txtNome.getText());

            ((Atendente)a).setEndereco(txtEndereco.getText());
            ((Atendente)a).setTelefone(txtTelefone.getText());

            if(rbtnManha.isSelected()){
                ((Atendente)a).setTurno("M");
            }
            else if (rbtnTarde.isSelected()){
                ((Atendente)a).setTurno("T");
            }
            else if (rbtnNoite.isSelected()){
                ((Atendente)a).setTurno("N");
            }

            atendentes.add(a);

            txtRegFuncional.setText(null);
            txtNome.setText(null);
            txtEndereco.setText(null);
            txtTelefone.setText(null);

            btnConsultar.setEnabled(true);
            btnInserir.setEnabled(false);

            txtRegFuncional.setEnabled(true);
            txtNome.setEnabled(false);
            txtEndereco.setEnabled(false);
            txtTelefone.setEnabled(false);

            rbtnManha.setEnabled(false);
            rbtnTarde.setEnabled(false);
            rbtnNoite.setEnabled(false);

            buttonGroup1.clearSelection();

            txtRegFuncional.requestFocus();
        }
    }//GEN-LAST:event_btnInserirActionPerformed

    private void btnAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAlterarActionPerformed
        atendentes.get(posAtendente).setEndereco(txtEndereco.getText());
        atendentes.get(posAtendente).setTelefone(txtTelefone.getText());
        
        if(rbtnManha.isSelected()){
            atendentes.get(posAtendente).setTurno("M");
        }
        else if (rbtnTarde.isSelected()){
            atendentes.get(posAtendente).setTurno("T");
        }
        else if (rbtnNoite.isSelected()){
            atendentes.get(posAtendente).setTurno("N");
        }
        
        txtRegFuncional.setText(null);
        txtNome.setText(null);
        txtEndereco.setText(null);
        txtTelefone.setText(null);
        
        txtRegFuncional.setEnabled(true);
        txtNome.setEnabled(false);
        txtEndereco.setEnabled(false);
        txtTelefone.setEnabled(false);
        
        buttonGroup1.clearSelection();
        rbtnManha.setEnabled(false);
        rbtnTarde.setEnabled(false);
        rbtnNoite.setEnabled(false);
        
        btnConsultar.setEnabled(true);
        btnAlterar.setEnabled(false);
        btnExcluir.setEnabled(false);
        
        txtRegFuncional.requestFocus();
    }//GEN-LAST:event_btnAlterarActionPerformed

    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcluirActionPerformed
        if (posAtendente >= 0) {
            atendentes.remove(posAtendente);
            posAtendente -= 1;
        }
        
        txtRegFuncional.setText(null);
        txtNome.setText(null);
        txtEndereco.setText(null);
        txtTelefone.setText(null);
        
        txtRegFuncional.setEnabled(true);
        txtNome.setEnabled(false);
        txtEndereco.setEnabled(false);
        txtTelefone.setEnabled(false);
        
        buttonGroup1.clearSelection();
        rbtnManha.setEnabled(false);
        rbtnTarde.setEnabled(false);
        rbtnNoite.setEnabled(false);
        
        btnConsultar.setEnabled(true);
        btnAlterar.setEnabled(false);
        btnExcluir.setEnabled(false);
        
        txtRegFuncional.requestFocus();
    }//GEN-LAST:event_btnExcluirActionPerformed

  
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAlterar;
    private javax.swing.JButton btnConsultar;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JButton btnInserir;
    private javax.swing.JButton btnSair;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel jLabelEndereco;
    private javax.swing.JLabel jLabelNome;
    private javax.swing.JLabel jLabelRegFunc;
    private javax.swing.JLabel jLabelTelefone;
    private javax.swing.JPanel jPanelTurno;
    private javax.swing.JRadioButton rbtnManha;
    private javax.swing.JRadioButton rbtnNoite;
    private javax.swing.JRadioButton rbtnTarde;
    private javax.swing.JTextField txtEndereco;
    private javax.swing.JTextField txtNome;
    private javax.swing.JTextField txtRegFuncional;
    private javax.swing.JTextField txtTelefone;
    // End of variables declaration//GEN-END:variables
    
    private ArrayList<Atendente> atendentes;
    private Atendente a = null;
    private int posAtendente;
}
