package fatec.poo.view;

import fatec.poo.model.Hospede;
import fatec.poo.model.QuartoHotel;
import java.util.ArrayList;

/**
 *
 * @author ***
 */
public class GuiAvaliacao2 extends javax.swing.JFrame {
    public GuiAvaliacao2(ArrayList<QuartoHotel> h, ArrayList<Hospede> ho) {
        initComponents();
        
        hotel = h;
        hospedes = ho;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabelQntQuartosOcup = new javax.swing.JLabel();
        jLabelQtdeQuartosMasc = new javax.swing.JLabel();
        jLabelTotalFat = new javax.swing.JLabel();
        jLabelQtdeOcupFem = new javax.swing.JLabel();
        btnPesquisar = new javax.swing.JButton();
        btnSair = new javax.swing.JButton();
        lblQtdeQuartosOcup = new javax.swing.JLabel();
        lblTotalFat = new javax.swing.JLabel();
        lblQtdeQuartosOcupMasc = new javax.swing.JLabel();
        lblQtdeQuartosOcupFem = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("2a. Avaliação de POO - Noite");

        jLabelQntQuartosOcup.setText("Qtde. de Quartos Ocupados");

        jLabelQtdeQuartosMasc.setText("Qtde. de Quartos Ocupados por Hóspedes do Sexo Masculino");

        jLabelTotalFat.setText("Total Faturamento Hotel");

        jLabelQtdeOcupFem.setText("Qtde. de Quartos Ocupados por Hóspedes do Sexo Feminino");

        btnPesquisar.setText("Pesquisar");
        btnPesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPesquisarActionPerformed(evt);
            }
        });

        btnSair.setText("Sair");
        btnSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSairActionPerformed(evt);
            }
        });

        lblQtdeQuartosOcup.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        lblTotalFat.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        lblQtdeQuartosOcupMasc.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        lblQtdeQuartosOcupFem.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelQntQuartosOcup)
                            .addComponent(jLabelTotalFat))
                        .addGap(34, 34, 34)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblTotalFat, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblQtdeQuartosOcup, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(btnPesquisar)
                            .addGap(18, 18, 18)
                            .addComponent(btnSair))
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabelQtdeQuartosMasc)
                                .addComponent(jLabelQtdeOcupFem))
                            .addGap(18, 18, 18)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(lblQtdeQuartosOcupMasc, javax.swing.GroupLayout.DEFAULT_SIZE, 157, Short.MAX_VALUE)
                                .addComponent(lblQtdeQuartosOcupFem, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                .addContainerGap(44, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabelQntQuartosOcup)
                    .addComponent(lblQtdeQuartosOcup, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabelTotalFat)
                    .addComponent(lblTotalFat, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(17, 17, 17)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabelQtdeQuartosMasc)
                            .addComponent(lblQtdeQuartosOcupMasc, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(30, 30, 30)
                        .addComponent(jLabelQtdeOcupFem))
                    .addComponent(lblQtdeQuartosOcupFem, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnPesquisar)
                    .addComponent(btnSair))
                .addGap(18, 18, 18))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSairActionPerformed
        dispose();
    }//GEN-LAST:event_btnSairActionPerformed

    private void btnPesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPesquisarActionPerformed
        int quarto;
        int qtdeQuartosOcupados = 0;
        double totalFaturaHotel = 0;
        
        for (quarto = 0; quarto < hotel.size(); quarto++){ 
            if (hotel.get(quarto) instanceof QuartoHotel) {
                if (hotel.get(quarto).getSituacao()) {
                    qtdeQuartosOcupados += 1;
                }
            }
            totalFaturaHotel += hotel.get(quarto).getTotalFaturado();
        }
         
        int hospM;
        int qtdeQuartoMasc = 0;
        
        
        for (hospM = 0; hospM < hospedes.size(); hospM++) {
            if (hospedes.get(hospM) instanceof Hospede) {
                if (((Hospede)hospedes.get(hospM)).getSexo().equals("M")){
                    posQuarto = hotel.indexOf(hospedes.get(hospM).getQuartoHotel());
                    if(hotel.get(posQuarto).getSituacao())
                        qtdeQuartoMasc += 1;
                    }
                }
            }
        int hospF;
        int qtdeQuartoFem = 0;
        
        for (hospF = 0; hospF < hospedes.size(); hospF++) {
            if (hospedes.get(hospF) instanceof Hospede) {
                if (((Hospede)hospedes.get(hospF)).getSexo().equals("F")){
                    posQuarto = hotel.indexOf(hospedes.get(hospF).getQuartoHotel());
                    if(hotel.get(posQuarto).getSituacao())
                        qtdeQuartoFem += 1;
                    }
                }
            }
            
        lblQtdeQuartosOcup.setText(String.valueOf(qtdeQuartosOcupados));
        lblTotalFat.setText(String.valueOf(totalFaturaHotel));
        lblQtdeQuartosOcupMasc.setText(String.valueOf(qtdeQuartoMasc));
        lblQtdeQuartosOcupFem.setText(String.valueOf(qtdeQuartoFem));
    }//GEN-LAST:event_btnPesquisarActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnPesquisar;
    private javax.swing.JButton btnSair;
    private javax.swing.JLabel jLabelQntQuartosOcup;
    private javax.swing.JLabel jLabelQtdeOcupFem;
    private javax.swing.JLabel jLabelQtdeQuartosMasc;
    private javax.swing.JLabel jLabelTotalFat;
    private javax.swing.JLabel lblQtdeQuartosOcup;
    private javax.swing.JLabel lblQtdeQuartosOcupFem;
    private javax.swing.JLabel lblQtdeQuartosOcupMasc;
    private javax.swing.JLabel lblTotalFat;
    // End of variables declaration//GEN-END:variables
    
    private ArrayList<QuartoHotel> hotel;
    private ArrayList<Hospede> hospedes;
    
    private QuartoHotel h = null;
    private Hospede ho = null;
    
    private int posQuarto;
}
