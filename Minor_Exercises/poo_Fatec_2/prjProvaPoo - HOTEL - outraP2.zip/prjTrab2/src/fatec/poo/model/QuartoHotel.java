package fatec.poo.model;

/**
 *
 * @author ***
 */
public class QuartoHotel {
    private int numQuarto;
    private double valorDiaria;
    private boolean situacao;
    private String dataEntrada;
    private double totalFaturado;
    private Hospede hospede;
    private Atendente atendente;

    public QuartoHotel(int numQuarto, double valorDiaria) {
        this.numQuarto = numQuarto;
        this.valorDiaria = valorDiaria;
    }
    
    public void reservar(Hospede hospede, Atendente atendente) {
        this.situacao = true;
        
        this.hospede = hospede;
        this.atendente = atendente;
        
        this.hospede.setQuartoHotel(this);
        this.atendente.addQuartoHotel(this);
    }
    
    public double liberar(int qntDiasHosped, double txDesc) {
        situacao = false;
        dataEntrada = null;
        
        hospede.setQuartoHotel(null);
        atendente.delQuartoHotel(this);
                
        totalFaturado += qntDiasHosped * valorDiaria * (1 - txDesc/100);
        
        return qntDiasHosped * valorDiaria * (1 - txDesc/100);
    }

    public void setDataEntrada(String dataEntrada) {
        this.dataEntrada = dataEntrada;
    }

    public int getNumQuarto() {
        return numQuarto;
    }

    public double getValorDiaria() {
        return valorDiaria;
    }

    public boolean getSituacao() {
        return situacao;
    }

    public String getDataEntrada() {
        return dataEntrada;
    }

    public double getTotalFaturado() {
        return totalFaturado;
    }

    public Hospede getHospede() {
        return hospede;
    }

    public Atendente getAtendente() {
        return atendente;
    }    
}
