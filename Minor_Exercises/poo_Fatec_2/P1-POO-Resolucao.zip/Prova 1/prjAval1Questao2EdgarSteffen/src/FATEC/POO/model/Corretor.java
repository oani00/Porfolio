
package FATEC.POO.model;

/**
 *
 * @author Edgar A Steffen
 */
public class Corretor extends Pessoa{
    private double taxaLocacao;
    private double totalLocacao;

    public Corretor(int Codigo, String Nome, double taxaLocacao) {
        super(Codigo, Nome);
        this.taxaLocacao = taxaLocacao;
    }

    public double getTaxaLocacao() {
        return taxaLocacao;
    }

    public double getTotalLocacao() {
        return totalLocacao;
    }
    
    public void addLocacao(double valorLocacao) {
        totalLocacao += valorLocacao;
    }
    
    public double calcValorComissaoLocacao() {
        return(totalLocacao / 100 * (getTotalLocacao()));
    }
}
