
package FATEC.POO.model;

/**
 *
 * @author Edgar A Steffen
 */
public class Pessoa {
    private int Codigo;
    private String Nome;

    public Pessoa(int Codigo, String Nome) {
        this.Codigo = Codigo;
        this.Nome = Nome;
    }

    public int getCodigo() {
        return Codigo;
    }

    public String getNome() {
        return Nome;
    }
}
