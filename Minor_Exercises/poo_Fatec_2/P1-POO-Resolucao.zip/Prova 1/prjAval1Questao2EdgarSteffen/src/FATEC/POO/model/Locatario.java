
package FATEC.POO.model;

/**
 *
 * @author Edgar A Steffen
 */
public class Locatario extends Pessoa{
    private double totalAluguel;

    public Locatario(int Codigo, String Nome) {
        super(Codigo, Nome);
    }

    public double getTotalAluguel() {
        return totalAluguel;
    }
    
    public void addAluguel(double valorAluguel, double taxaLocacao) {
        totalAluguel += valorAluguel - taxaLocacao;
    }
}