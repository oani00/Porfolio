
import FATEC.POO.model.Corretor;
import FATEC.POO.model.Locatario;
import java.text.DecimalFormat;

/**
 *
 * @author Edgar A Steffen
 */
public class Aplic {
    public static void main(String[] args) {
        DecimalFormat df = new DecimalFormat("#,##0.00");
        Locatario[] objLocator = new Locatario[2];        
        objLocator[0] = new Locatario(111, "Edgar Augusto");
        objLocator[1] = new Locatario(222, "Edy Steffen");
        Corretor objCorretor = new Corretor(2, "Ariovaldo Gomes", 5);
        
        objCorretor.addLocacao(780);
        objCorretor.addLocacao(1500);
        objCorretor.addLocacao(650);
        
        objLocator[0].addAluguel(780, objCorretor.getTaxaLocacao());
        objLocator[1].addAluguel(1500, objCorretor.getTaxaLocacao());
        objLocator[1].addAluguel(650, objCorretor.getTaxaLocacao());
        
        System.out.println("Corretor \nCodigo: " + objCorretor.getCodigo() + "\nNome: " + objCorretor.getNome() + "\nTaxa de locacao: " + df.format(objCorretor.getTaxaLocacao()) + "\nComissao: " + df.format(objCorretor.calcValorComissaoLocacao()) + "\nTotal de locacao: " + df.format(objCorretor.getTotalLocacao()));
        
        for (int i = 0; i < objLocator.length; i++) {
            System.out.println("\n\nLocatario " + (i + 1) + "\nCodigo: " + objLocator[i].getCodigo() + "\nNome: " + objLocator[i].getNome() + "\nTotal de aluguel: " + df.format(objLocator[i].getTotalAluguel()));
        }
    }
}
