
import FATEC.POO.model.Comodo;
import java.text.DecimalFormat;
import java.util.Scanner;

/**
 *
 * @author Edgar A Steffen
 */
public class Aplic {
    public static void main(String[] args) {
       DecimalFormat df = new DecimalFormat("0.0");	
       Scanner entrada = new Scanner(System.in);
              
       Comodo[] lampComodo = new Comodo[5];
       
       double medLarg, medComp, medAlt;
       int i, potLampada, tipo;
       
       for(i = 0; i < 5; i++) {
           System.out.println("Informe o tipo (1 sala - 2 quarto - 3 cozinha - 4 banheiro): ");
           tipo = entrada.nextInt();
           
           System.out.println("Informe a potencia da lâmpada: ");
           potLampada = entrada.nextInt();
           
           lampComodo[i] = new Comodo(tipo, potLampada);
           
           System.out.println("Digite a medida da largura: ");
           medLarg = entrada.nextDouble();       
           System.out.println("Digite a medida da comprimento: ");
           medComp = entrada.nextDouble();
           System.out.println("Digite a medida da altura: ");
           medAlt = entrada.nextDouble();
           
           lampComodo[i].setMedAlt(medAlt);
           lampComodo[i].setMedComp(medLarg);
           lampComodo[i].setMedLarg(medComp);
       }
       
       System.out.println("\n\nTipo Cômodo \t Potência Lâmpada \t No. Aprox. de Lâmpadas");
       for (i = 0; i < 5; i++) {
           System.out.println("\t" + lampComodo[i].getTipo() + " \t\t " + lampComodo[i].getPotLampada() + " \t\t " + df.format(lampComodo[i].calcQtdeLampada()));
       }
    }
}
