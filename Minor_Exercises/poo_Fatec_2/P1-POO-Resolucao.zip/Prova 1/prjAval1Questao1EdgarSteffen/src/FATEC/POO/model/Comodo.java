
package FATEC.POO.model;

/**
 *
 * @author Edgar A Steffen
 */
public class Comodo {
    private int tipo;
    private double medLarg;
    private double medComp;
    private double medAlt;
    private int potLampada;

    public Comodo(int tipo, int potLampada) {
        this.tipo = tipo;
        this.potLampada = potLampada;
    }

    public void setMedLarg(double medLarg) {
        this.medLarg = medLarg;
    }

    public void setMedComp(double medComp) {
        this.medComp = medComp;
    }

    public void setMedAlt(double medAlt) {
        this.medAlt = medAlt;
    }

    public int getTipo() {
        return tipo;
    }

    public int getPotLampada() {
        return potLampada;
    }
    
    public double calcQtdeLampada() {
        int potMinima;
        if (tipo == 1) {
            potMinima = 20;
        } else if (tipo == 2) {
            potMinima = 25;
        } else if (tipo == 3) {
            potMinima = 18;
        } else {
            potMinima = 15;
        }
        
        return ((potMinima * (medAlt * medComp * medLarg)) / potLampada);
    }
}
