
import fatec.poo.util.ValidaCPF;
import fatec.poo.view.GuiMenu;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Guilherme Henrique Mello e Almeida
 * @author Luiz Miguel Jarduli Leite
 */
public class Main {
    public static void main(String[] args) {
        GuiMenu menu = new GuiMenu();
        menu.setVisible(true);
    }
}
